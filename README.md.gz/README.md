# csc3422_server
> Stage 3 CSC3422 Server Coursework
> Contains the whole implemented apache2 server. 

# Basic information
Address: 10.66.68.83

# Coursework 2:
#### Configuration files
> Please search for pattern "dtn" to see modifications made.

#### Authentication details 
> (applies for both /dbrestricted and /filerestricted)
- username: alice
- password: 12345



